# Kage Magg — auto-updating site

Ye site apne aap update hoti hai:
- **YouTube:** naye videos (bina key ke) + subscribers / video count (YT_API_KEY se)
- **Instagram:** followers, posts aur naye reels (IG_TOKEN se)
Agar koi key nahi lagayi, to site purana built-in content dikhati rahegi — kuch toot'ta nahi.

## Deploy (free, Vercel)
1. Is folder ko GitHub par ek naye repo mein upload karo.
2. vercel.com par login -> "Add New Project" -> wo repo import karo (koi framework nahi, bas Deploy).
3. Project Settings -> Environment Variables mein ye daalo (neeche dekho), phir Redeploy.

## YT_API_KEY (subscribers ke liye, optional)
Google Cloud Console -> naya project -> "YouTube Data API v3" enable -> Credentials -> Create API key.
Naye videos iske bina bhi aa jaate hain.

## IG_TOKEN (followers + reels ke liye)
1. Instagram account ko Professional (Creator) banao: Settings -> Account type.
2. developers.facebook.com par app banao -> "Instagram API with Instagram Login" -> apna account jodo -> access token generate karo.
3. Token ko IG_TOKEN mein daalo. Ye token lagbhag 60 din chalta hai, phir refresh karna padta hai
   (Meta ki settings badalti rehti hain; naye steps unke docs mein dekh lena).

## Cache
YouTube data ~15 min aur Instagram data ~30 min mein refresh hota hai.
