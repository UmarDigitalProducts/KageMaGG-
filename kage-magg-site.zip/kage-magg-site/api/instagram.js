// Vercel serverless function: follower count + latest reels via the Instagram API (needs IG_TOKEN).
module.exports = async (req, res) => {
  const token = process.env.IG_TOKEN;
  if (!token) return res.status(200).json({ configured: false });
  try {
    const api = 'https://graph.instagram.com';
    const me = await (await fetch(`${api}/me?fields=username,followers_count,media_count&access_token=${token}`)).json();
    const media = await (await fetch(`${api}/me/media?fields=id,caption,media_type,media_product_type,thumbnail_url,media_url,permalink,timestamp&limit=12&access_token=${token}`)).json();
    if (me.error) throw new Error(me.error.message);
    const reels = (media.data || [])
      .filter((m) => m.media_product_type === 'REELS' || m.media_type === 'VIDEO')
      .map((m) => ({ link: m.permalink, thumb: m.thumbnail_url || m.media_url, caption: m.caption || '' }))
      .filter((m) => m.thumb);
    res.setHeader('Cache-Control', 's-maxage=1800, stale-while-revalidate=7200');
    res.status(200).json({ configured: true, followers: me.followers_count, posts: me.media_count, reels });
  } catch (e) {
    res.status(500).json({ configured: false, error: 'instagram_failed' });
  }
};
