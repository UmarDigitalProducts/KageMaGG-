// Vercel serverless function: latest videos (RSS, no key needed) + channel stats (needs YT_API_KEY).
const CHANNEL_ID = 'UCaGRLG7rIzSluWLpcvmg9TA';

function decode(s = '') {
  return s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}

module.exports = async (req, res) => {
  try {
    let stats = null;
    const key = process.env.YT_API_KEY;
    if (key) {
      const r = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${CHANNEL_ID}&key=${key}`);
      const j = await r.json();
      const s = j.items && j.items[0] && j.items[0].statistics;
      if (s) stats = { subscribers: Number(s.subscriberCount), videos: Number(s.videoCount), views: Number(s.viewCount) };
    }
    const xml = await (await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${CHANNEL_ID}`)).text();
    const videos = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].slice(0, 8).map((m) => {
      const e = m[1];
      return {
        id: (e.match(/<yt:videoId>(.*?)<\/yt:videoId>/) || [])[1],
        title: decode((e.match(/<title>(.*?)<\/title>/) || [])[1]),
        published: (e.match(/<published>(.*?)<\/published>/) || [])[1],
      };
    }).filter((v) => v.id);
    res.setHeader('Cache-Control', 's-maxage=900, stale-while-revalidate=3600');
    res.status(200).json({ stats, videos });
  } catch (e) {
    res.status(500).json({ error: 'youtube_failed' });
  }
};
